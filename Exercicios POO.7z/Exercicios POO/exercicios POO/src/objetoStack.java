

public class ObjectStack<P> implements Stack<T> {
	
    private Node<P> top; 

    
    private class Node<T> {
		
        private P data;
		
        private Node<T> next;

        public Node(P data) {
			
            this.data = data;
			
            next = null;
        }
        public P getData() {
			
            return data;
        }

        public void setData(P data) {
			
            this.data = data;
        }

        public Node<P> getNext() {
			
            return next;
        }

        public void setNext(Node<P> next) {
			
            this.next = next;
        }
    }

    public ObjectStack() {
		
        top = null;
    }

   
   
    public void push(P data) {
        
		
        Node<P> aux = new Node<>(data);

        
		
        if (isEmpty()) {
			
            top = aux;
			
        } else {
			
            aux.next = top;
			
            top = aux;
			
        }
    }

    
    public P pop() {
		
        Node<P> aux;
		
        P data; 

        
        if (isEmpty()) {
			
            throw new IndexOutOfBoundsException("Pilha 0%!");
        }
        
        aux = top; 
		
        top = top.next; 
		
        aux.next = null; 
		
        data = aux.data; 
        

        
        return data;
    }

    
    public boolean isEmpty() {
        return (top == null);
    }
}
