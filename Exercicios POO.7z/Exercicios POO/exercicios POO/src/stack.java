public interface Stack<P> {
	
    void push(P data);
	
    boolean isEmpty();
	
	P pop();
}